# Copyright (C) 2015 - Philipp Temminghoff <phil65@kodi.tv>
# Modifications copyright (C) 2026 - Scott Smart <scott967@kodi.tv>
# This program is Free Software see LICENSE file for details
"""Main class object run when called by Runscript() as executable in Kodi
Note:  Endpoints from Trakt are no longer supported.  If called with
info=trending, info=popular, info=anticipated, info=collected, info=watched,
info=recommended or info=watchlist, the request will be ignored/logged and no data will be returned.
"""
from __future__ import annotations

import sys

from resources.kutil131 import addon, utils
from resources.lib import process

TRAKT_ENDPOINTS = ["trending", "popular", "anticipated",
                   "collected", "watched", "recommended", "watchlist"]


def pass_list_to_skin(name: str, data, prefix: str = "", limit: int = False) -> None:
    """Set home window properties from the data

    SetProperty(prefixname.%d.data_item key,data_item value, home) for 1 to
    limit number of items in data

    Args:
        name (str): Type of data being returned derived from runscript info
            parameter.  Used to construct the skin window property key
            eg. topratedmovies from invocation parameter info=
        data (kutils131.itemlist.ItemList): collection of ListItems
            (Video or Audio)
        prefix (str, optional):  Optional prefix for the name.  May be set
            as a param in runscript.  Defaults to "".
        limit (int, optional):  Number of items to return. May be set as a param
            in runscript.  Defaults to False.

    Returns:
        None
    """
    if data and limit and int(limit) < len(data):
        data = data[:int(limit)]
    if not data:
        addon.set_global(f'{prefix}{name}.Count', '0')
        return None
    for (count, result) in enumerate(data):
        for (key, value) in result.get_infos().items():
            addon.set_global(f'{prefix}{name}.{count + 1}.{key}', str(value))
        for key, value in result.get("properties", {}).items():
            if not value:
                continue
            addon.set_global(f'{prefix}{name}.{count + 1}.{key}', str(value))
    addon.set_global(f'{prefix}{name}.Count', str(len(data)))


class Main:
    """When called by Runscript provides all functionality.  Multiple instances
    of Main can be created.  No class attributes or methods are provided
    """

    def __init__(self):
        """Initializes the main process as object when extendedinfo is called as script

        Parse the invocation argument strings to create self.infos (called with
        info= args) list and self.params dict  (called with param=value pairs)
        If started with no parameters, opens the video list dialog with movies
        from TMDB retrieved by popularity.   TRAKT endpoints no longer supported.
        """
        utils.log(f"version {addon.VERSION} started")
        addon.set_global("extendedinfo_running", "true")
        # utils.log(f'default.Main setting setting_update is {addon.bool_setting("setting_update_6.0.9")}')
        if not addon.bool_setting("setting_update_6.0.9"):
            addon.update_lang_setting()
        utils.log(
            f'default.Main setting LanguageIDv2 after update {addon.setting("LanguageIDv2")}', adb=True)
        self._parse_argv()
        for info in self.infos:
            listitems = process.start_info_actions(info, self.params)
            pass_list_to_skin(name=info,
                              data=listitems,
                              prefix=self.params.get("prefix", ""),
                              limit=self.params.get("limit", 20))
        if not self.infos:
            addon.set_global('infodialogs.active', "true")
            try:
                from resources.lib.windowmanager import wm
                wm.open_video_list()
            finally:
                addon.clear_global('infodialogs.active')
        addon.clear_global("extendedinfo_running")

    def _parse_argv(self) -> None:
        """gets arguments passed by Runscript call and passes them as
        instance attributes of self.infos list (invoked with info=)
        and self.params dict
        """
        self.infos: list[str] = []
        self.params: dict[str, str] = {"handle": None}
        utils.log(f'default._parse_argv argv[1:] {sys.argv[1:]}', adb=True)
        for arg in sys.argv[1:]:
            # utils.log(f'default._parse_argv arg is {arg}')
            param = arg.replace('"', '').replace("'", " ")
            if param.startswith('info='):
                if param[5:] in TRAKT_ENDPOINTS:
                    utils.log(
                        f'default._parse_argv info= {param[5:]} is a TRAKT endpoint: ignored', adb=True)
                else:
                    self.infos.append(param[5:])
                    # utils.log(f'default._parse_argv self.infos is {self.infos}')
            else:
                try:
                    self.params[param.split('=', maxsplit=1)[0].lower()] = "=".join(
                        param.split("=")[1:]).strip()
                    utils.log(
                        f'default._parse_argv self.params {self.params}', adb=True)
                except Exception:
                    pass
        utils.log(
            f'default._parse_argv final self.infos {self.infos} self.params {self.params}')
